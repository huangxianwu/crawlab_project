# 数据模型包
from .product import ProductData

__all__ = ['ProductData']